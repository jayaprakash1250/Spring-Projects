package com.boa.kycprocess.configurations;

import java.util.List;

import javax.transaction.Transaction;

public interface TransactionData {

	List getAllTransactions();
}
